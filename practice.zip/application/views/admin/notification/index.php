<!-- Page Content -->
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Notifications  
					<a href="<?php echo SITEURL.'admin/AddNotification'; ?>"><button type="button" class="btn btn-outline btn-primary">Add New Notification</button>
					</a>
				</h1>
				<?php echo $Details;	?>			
			</div>
			<!-- /.col-lg-12 -->
		</div>
		<!-- /.row -->
	</div>
</div>