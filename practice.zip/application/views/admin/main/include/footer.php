  <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 

    <!-- Bootstrap Core JavaScript -->
   <script src="<?php echo BASE_URL;?>static/js/bootstrap.min.js"></script>  

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo BASE_URL;?>static/admin/js/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
	<script src="<?php echo BASE_URL;?>static/admin/js/sb-admin-2.js"></script>  
	<?php if(isset($additional)){	echo $additional;	} ?>	
	
</body>

</html>