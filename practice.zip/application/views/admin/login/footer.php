<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-10 col-lg-offset-1 col-md-12">        
        <div class="copyright-pk">
          <p>� 2017 ForceFlexing.com</p>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo BASE_URL;?>static/js/bootstrap.min.js"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/4.0.1/placeholders.min.js"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.6/owl.carousel.min.js"></script> 
<script src="<?php echo BASE_URL;?>static/js/nicescroll.min.js"></script> 
<script src="<?php echo BASE_URL;?>static/js/custom.js"></script>
</body>
</html>
