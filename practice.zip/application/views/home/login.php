<main role="main">
  <section class="login-wrap">
  <div class="container">
  <aside class="login-box">
  <h1>Create a Free Client Account</h1>
  <p>Looking for work?  <a href="#">Sign up as a freelancer</a></p>
  <div class="signup-btns"><a href="#" class="linked-in-btn"><i class="fa fa-linkedin" aria-hidden="true"></i><span>Sign up with LinkedIn</span></a>
  <a href="#" class="email-btn">Sign up with email</a> </div>                
  </aside>
  </div>
  </section>
</main>