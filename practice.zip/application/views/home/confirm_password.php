<main role="main">
  <section class="login-wrap">
    <div class="container">
      <aside class="login-box">
        <h1>Please enter new password</h1>
         <form class="login-form clearfix">
			  <label for="new_password">New Password</label>
			  <input id="new_password" name="" type="password" class="input">
			  <label for="confirm_password">Confirm Password</label>
			  <input id="confirm_password" name="" type="password" class="input">
			  <input name="" type="submit" value="Submit" class="btn btn-blue">
        </form>
         
         
      </aside>
    </div>
  </section>
</main>