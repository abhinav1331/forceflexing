<section class="emp-areas dynamicpage <?php echo $data['slug']; ?>">
    <div class="container">
      <h2><?php echo $data['title']; ?></h2>
      <div class="row">
        <?php echo $data['content']; ?>
      </div>      
    </div>
</section>