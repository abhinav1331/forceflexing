<main role="main">
        <section class="page-wrap open-jobs-pending-activites">
            <div class="container">
                <div class="page-main">				
                    <div class="open-jobs">
                        <h2>Open Jobs</h2>
					<div class="openjobsList">	
                        <article>
                            <div class="open-job-info">
                                <h3><a href="#">Website from scratch for mobile app</a></h3>
                                <ul class="job-posted-info">
                                    <li>Posted: 12-3-2016</li>
                                    <li>Posted: 12-3-2016</li>
                                </ul>
                                <ul class="view-jobs-btn-group">
                                    <li><a href="#">View Activity Detail</a></li>
                                    <li><a href="#">View suggested contractors</a></li>
                                </ul>
                            </div>
                            <div class="open-jobs-task">
                                <ul>
                                    <li><big>10 <span>(5 new)</span></big>Applicants</li>
                                    <li><big>4</big>Messaged</li>
                                    <li><big>2</big>Offers</li>
                                    <li><big>1</big>Hired</li>
                                </ul>
                            </div>
                            <div class="open-jobs-action">
                                <div class="dropdown">
                                    <button class="btn btn-blue dropdown-toggle" type="button" id="actions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Actions <i class="fa fa-angle-down" aria-hidden="true"></i> </button>
                                    <ul class="dropdown-menu blue animated fast fadeInUpSmall" aria-labelledby="actions">
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="viewPost"> <span class="radio"></span>View Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="editPost"> <span class="radio"></span>Edit Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="removePost"> <span class="radio"></span>Remove Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="duplicatePost"> <span class="radio"></span>Duplicate Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="makePrivate"> <span class="radio"></span>Make Private</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </article>
                        <article>
                            <div class="open-job-info">
                                <h3><a href="#">Website from scratch for mobile app</a></h3>
                                <ul class="job-posted-info">
                                    <li>Posted: 12-3-2016</li>
                                    <li>Posted: 12-3-2016</li>
                                </ul>
                                <ul class="view-jobs-btn-group">
                                    <li><a href="#">View Activity Detail</a></li>
                                    <li><a href="#">View suggested contractors</a></li>
                                </ul>
                            </div>
                            <div class="open-jobs-task">
                                <ul>
                                    <li><big>10 <span>(5 new)</span></big>Applicants</li>
                                    <li><big>4</big>Messaged</li>
                                    <li><big>2</big>Offers</li>
                                    <li><big>1</big>Hired</li>
                                </ul>
                            </div>
                            <div class="open-jobs-action">
                                <div class="dropdown">
                                    <button class="btn btn-blue dropdown-toggle" type="button" id="actions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Actions <i class="fa fa-angle-down" aria-hidden="true"></i> </button>
                                    <ul class="dropdown-menu blue animated fast fadeInUpSmall" aria-labelledby="actions">
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="viewPost"> <span class="radio"></span>View Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="editPost"> <span class="radio"></span>Edit Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="removePost"> <span class="radio"></span>Remove Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="duplicatePost"> <span class="radio"></span>Duplicate Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="makePrivate"> <span class="radio"></span>Make Private</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </article>
                        <article>
                            <div class="open-job-info">
                                <h3><a href="#">Website from scratch for mobile app</a></h3>
                                <ul class="job-posted-info">
                                    <li>Posted: 12-3-2016</li>
                                    <li>Posted: 12-3-2016</li>
                                </ul>
                                <ul class="view-jobs-btn-group">
                                    <li><a href="#">View Activity Detail</a></li>
                                    <li><a href="#">View suggested contractors</a></li>
                                </ul>
                            </div>
                            <div class="open-jobs-task">
                                <ul>
                                    <li><big>10 <span>(5 new)</span></big>Applicants</li>
                                    <li><big>4</big>Messaged</li>
                                    <li><big>2</big>Offers</li>
                                    <li><big>1</big>Hired</li>
                                </ul>
                            </div>
                            <div class="open-jobs-action">
                                <div class="dropdown">
                                    <button class="btn btn-blue dropdown-toggle" type="button" id="actions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Actions <i class="fa fa-angle-down" aria-hidden="true"></i> </button>
                                    <ul class="dropdown-menu blue animated fast fadeInUpSmall" aria-labelledby="actions">
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="viewPost"> <span class="radio"></span>View Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="editPost"> <span class="radio"></span>Edit Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="removePost"> <span class="radio"></span>Remove Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="duplicatePost"> <span class="radio"></span>Duplicate Post</label>
                                        </li>
                                        <li>
                                            <label class="radio-custom">
                                                <input type="radio" name="one" value="one1" id="makePrivate"> <span class="radio"></span>Make Private</label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </article> 
                        <a href="javascript:void(0);" class="pro-more-toggle">Back to Jobs <i class="fa fa-angle-down" aria-hidden="true"></i></a> 
                    </div>
						<div class="contractor-pagination">
							<div class="pagination nextjobs">
							</div>
						</div>
                    </div>
                </div>
            </div>
        </section>
    </main>
	<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
		<div class="forgotPassword" style="padding:40px; position:relative">
			<a href="javascript:void(0);" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></a>
			<div class="removePost" style="display:none;">
				<h2>Delete Post ?	</h2>
				<h4>Are you sure you want to delete this post?	</h4>
				<button rel="" class="btn btn-blue delete_id">DELETE</button>
				<button class="btn btn-blue cancel">CANCEL</button>
			</div>
			<div style="display:none;" class="duplicatePost">
				<h2><?php 
				if(isset($joblist))
				{
					echo "Please Select Previous Job";
				}
				
				?></h2>
					<div class="message"></div>		
				 <?php 
				if(isset($joblist))
				{
					echo"<select class='input job_id' name='job'>";
						echo "<option>Select Job</option>";
							foreach($joblist as $keys):
								echo "<option value='$keys[id]'>".$keys['job_title']."</option>";
							endforeach;
					echo"</select>";
				}
				
				?>   
				<button class="btn btn-blue job_in">SUBMIT</button>
			</div>
		</div>	
    </div>
  </div>
</div>
