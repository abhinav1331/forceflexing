<header class="header">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#topnav" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar top-bar"></span> <span class="icon-bar middle-bar"></span> <span class="icon-bar bottom-bar"></span> </button>
    </div>
    <div class="logo"><a href="<?php echo SITEURL; ?>""><img src="<?php  echo BASE_URL;?>static/images/logo.png"></a></div>
    <nav class="topnav not-logged-in">
      <div class="collapse navbar-collapse" id="topnav">
        <ul>
          <li class="login">
            <p>Already have an ForceFlexing account?</p>
            <a href="<?php echo BASE_URL;?>login"><i class="fa fa-sign-in" aria-hidden="true"></i> log-in</a></li>
        </ul>
      </div>
    </nav>
  </div>
</header>