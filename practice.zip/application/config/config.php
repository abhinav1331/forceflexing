<?php 

$config['base_url'] = 'http://force.imarkclients.com/'; // Base URL including trailing slash (e.g. http://localhost/)
$config['ABSPATH'] = dirname(__FILE__); // Base URL including trailing slash (e.g. http://localhost/)

$config['default_controller'] = 'home'; // Default controller to load
$config['error_controller'] = 'error'; // Controller used for errors (e.g. 404, 500 etc)

$config['db_host'] = 'localhost'; // Database host (e.g. localhost)
$config['db_name'] = 'imarkcli_forceflexing'; // Database name
$config['db_username'] = 'imarkcli_forcefl'; // Database username
$config['db_password'] = 'e8m]~$wfz@3Z'; // Database password

?>